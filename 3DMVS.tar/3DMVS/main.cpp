#include "./common/common.hpp"

int main(int argc,char** argv) {
    ASSERT_OK(MV3D_LP_Initialize());
    LOGD("Main done!");
    return  0;
}